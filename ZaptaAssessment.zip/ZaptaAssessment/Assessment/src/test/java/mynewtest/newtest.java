package mynewtest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class newtest {
    public static void main(String[] args) {

        // this step is done becuase i having some issue running the chrome.
        ChromeOptions co=new ChromeOptions();
        co.addArguments("--remote-allow-origins=*");

        // set the path of the webdriver.
        System.setProperty("webdriver.chrome.driver","C:\\Users\\SSC\\Downloads\\newchromedriver\\chromedriver-win64\\chromedriver.exe");
        WebDriver driver = new ChromeDriver(co);

        // navigate to the main url.
        driver.get("https://www.staysucasa.com/ ");
        String str =driver.getCurrentUrl();
        driver.manage().window().maximize();
        System.out.println(str);


        // Go to The Sucasa Standard section
        WebElement sucasaStandardSection = driver.findElement(By.cssSelector("//h2[normalize-space()='The Sucasa Standard']"));
        //sucasaStandardSection.click();

        // Verify that The Sucasa Standard section contains the specified text
        verifyTextPresent(driver, "Work From Anywhere");
        verifyTextPresent(driver, "Transparent Pricing");
        verifyTextPresent(driver, "Premium Properties");


        // Go to Work From Anywhere section
        driver.findElement(By.xpath("/html/body/div[7]/div[3]/div/div/div/div[1]/h2"));

        //click on the Find stay button.
       driver.findElement(By.cssSelector("a[class=\"mx-auto mx-md-0\"]")).click();
        String ExpectedUrl="https://www.staysucasa.com/index?#featured";
        String actualUrl = driver.getCurrentUrl();

        // varification of Urls
      if (ExpectedUrl.equals(actualUrl)){
          System.out.println("Same Url as per Requirement");
      }
      else {
          System.out.println("Not as expected");
      }
      driver.quit();

    }
    private static void verifyTextPresent(WebDriver driver, String text) {
        WebElement element = driver.findElement(By.cssSelector("(//div[@class='d-flex flex-wrap flex-container justify-content-center justify-content-xl-between'])[1]" + text + "')]"));
        if (element.isDisplayed()) {
            System.out.println("Text verification passed: " + text);
        } else {
            System.out.println("Text verification failed: " + text);
        }

    }
}